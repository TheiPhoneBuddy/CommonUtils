//
//  CommonUtils.h
//  CommonUtils
//
//  Created by Francis Chan on 5/5/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CommonUtils.
FOUNDATION_EXPORT double CommonUtilsVersionNumber;

//! Project version string for CommonUtils.
FOUNDATION_EXPORT const unsigned char CommonUtilsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CommonUtils/PublicHeader.h>


